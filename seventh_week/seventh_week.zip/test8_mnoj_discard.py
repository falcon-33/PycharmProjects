mySet = {2, 3, 5, 8, 11}
mySet.discard(6)
print(*mySet)
