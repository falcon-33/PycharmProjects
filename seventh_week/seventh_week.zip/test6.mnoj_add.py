mySet = {2, 3, 5, 8, 11}
mySet.add(17)
print(*mySet)
