mySet = {1, 2, 3, 4, 50000, 6000000}
for elem in mySet:
    print(elem)
