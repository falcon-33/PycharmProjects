mySet = set('avcddddddesfg')
print(len(mySet))
