a = {1, 2, 3, 4}
b = {1, 3}
print(a == b)
print(a != b)
print(a > b)
print(a < b)
print(a <= b)
print(a >= b)
