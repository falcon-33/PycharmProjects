myList = map(int, input().split())
mySet = set(myList)
print(mySet)