mySet = {1, 3.14, 'abcd', frozenset({1, 2})}
print(mySet)
print(*mySet)