mySet = {1, 2, 3, 400000}
print(*sorted(list(mySet)))
