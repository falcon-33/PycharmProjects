mySet = {2, 3, 5, 8, 11}
mySet.remove(10)
print(*mySet)
