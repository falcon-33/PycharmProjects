myList = list(map(int, input().split()))
mySet = set(myList)
print(len(mySet))
