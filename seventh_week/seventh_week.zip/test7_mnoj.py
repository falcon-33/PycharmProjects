mySet = {1, 2, 3, 4, 5, 6, 11, 23, 89}
n = int(input())
if n not in mySet:
    print('not in set')
else:
    print('in set')
